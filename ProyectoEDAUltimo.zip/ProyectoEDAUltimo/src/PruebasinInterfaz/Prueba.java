
package PruebasinInterfaz;
import java.util.Scanner;
import  modeloLogica.*;

public class Prueba {
    
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        // se crea la gestion del empleado el cual estara funcionando todo el rato
        Gestion gestion=new Gestion();
        
        // interfaz de comienzo boton de ingresar y registrar o salir
         while(true){
        System.out.println("Bienvenido al registro de persona selecciona que operacion quiere realizar : ");
        System.out.println(" ");
        System.out.println("INGRESAR (MAYUSCULA): ");
        System.out.println("REGISTRAR(MAYUSCULA): ");
        System.out.println("escribe cualquier otra palabra para salir : ");
        
        String respuesta=sc.next();
        
        
        switch(respuesta){
            // en el caso la respuesta sea registrar te preguntaran los datos  y se creara una persona del sistema//
            case "REGISTRAR":
                System.out.println("Ingrese nombre: ");
                String nombre=sc.next();
                System.out.println("Ingrese apellido: ");
                String apellido=sc.next();
                System.out.println("Ingrese dni: ");
                int dni=sc.nextInt();
                System.out.println("Ingrese correo ");
                String correo=sc.next();
                System.out.println("Ingrese codigo");
                int codigo=sc.nextInt();
                System.out.println("Crea nombre  Usuario: ");
                String usuario=sc.next();
                System.out.println("Crea contraseña: ");
                String contraseña=sc.next();
                
                //Se selecciona en un check en la interfaz  para ingresar el atributo que determinara si el agente sera un empleado externo a la universidad o si es un personal de una dependencia
                System.out.println("INDIQUE COMO QUE TIPO DE PERSONA QUIERE INGRESAR ES SU RUBRO ");
                System.out.println(" ");
                System.out.println(" 1. EMPLEADO: ");
                System.out.println(" 2. PERSONAL");
                System.out.println("3. escribe una palabra para salir del programa");
                respuesta=sc.next();
                switch(respuesta){
                    // en caso la respuesta sea empleado se seleccionara el cargo en una lista de cargos mostrada por la interfaz
                    case "EMPLEADO":
                       
                        System.out.println("Ingresar cargo: ");
                        String cargo=sc.next();
                        //se crea un empleado y se ingresa en la listaenlazadadeempleados de mi clase gestion
                        Empleado empleado=new Empleado(nombre,apellido,dni,correo,codigo,cargo,usuario,contraseña);
                        gestion.AgregarEmpleado(empleado);
                        
                        
                        break;
                    // en caso el check seleccionado de la interfaz sea un personal se elije de la lista una dependencia  se crea el personal y se agregaalalistadepersonal           
                    case "PERSONAL":
                        
                         System.out.println("Ingresa A LA DEPENDECIA QUE quieres Pertenecer: ");
                         String dependencia=sc.next();
                         Personal personal=new Personal(dependencia,contraseña,usuario,nombre,apellido,dni,correo,codigo);
                         gestion.AgregarPersonal(personal);
                         break;
                         
                    default:
                        System.out.println("HAZ SALIDO DEL PROGRAMA: ");
                        
                        System.exit(0);
                }
                break;
                
            case  "INGRESAR"://en caso pongas el boton de ingresar pones tu nombre de usuario y contraseña 
                     System.out.println("Ingrese su Nombre de usuario: ");
                     usuario=sc.next();
                     System.out.println("Ingrese su  contraseña: ");
                     contraseña=sc.next();
                     int respuesta2;
                     
                     // el sistema validara a la persona por el usuario y la contraseña ingresado
                     if(gestion.ValidarEmpleado(usuario, contraseña)==true){
                         Empleado empleadoingresado=gestion.Retornarempleadovalidad(usuario, contraseña);//se asigna ala variable empleadoingresado el Objeto empleado validado 
                         //Una vez validado el empleado se pregunta si quiere realizar el expediente o quiere ver el estado de los expediente mandados
                         System.out.println("QUIERE REALIZAR EXPEDIENTE PONGA 1: ");
                         System.out.println("  ");
                         System.out.println("QUIERE VISUALIZAR SUS TRAMITES HECHOS PONGA 2: ");
                          respuesta2=sc.nextInt();
                         if(respuesta2==1){
                             // si pone hacer expediente se realiza el expediente y se agrega a la lista de expedientes por finalizar de mi clase gestion
                             gestion.AgregarExpediente(empleadoingresado.RealizarExpediente());
                             
                             break;
                             
                         }else if(respuesta2==2){
                             //si seleccion ver los  tramites se visualiza la cola de los expedientes realizados por este empleado  ya ordenados de manera que tendra como primero en la cola a los que tengan mayor prioridad
                             empleadoingresado.SeguirTramite();
                             
                             break;
                             
                         }
                         else{
                             System.exit(0);
                         }  
                         
                         
                        
                     }
                     //se valida a la persona en este caso los usuarios y contraseñas de un personal mediante la busqueda de la lista del personaldependencia
                     else if(gestion.ValidarPersonal(usuario, contraseña)==true){
                         Personal personalingresado=gestion.RetornarPersonalValidad(usuario, contraseña);//se asigna el valor del personal validado a la variable personal ingresado
                         
                         
                         personalingresado.RegistraIngresoExpediente(gestion.getListaexpedientes());// se muestra en  la cola del personal los expedientes de su misma dependencia que estan pedientes o para enviar a ser revisado o para finalizarlos
                         personalingresado.getCola().eliminarRepetidos();
                         personalingresado.getCola().Mostrar();
                         System.out.println("Revisar y finalizar expediente presione 1 ");
                         
                        
                         
                         respuesta2=sc.nextInt();
                         if(respuesta2==1){//si pone revisar o finalizar expediente
                             Expediente expedientetemp=personalingresado.getCola().Desencolar();//se desencola el expediente de la cola del personal
                             personalingresado.getPila().push(expedientetemp);
                             
                             gestion.getListaexpedientesfinalizados().Agregarelemento(expedientetemp);
                             gestion.getListaexpedientes().EliminarElementodeLista(expedientetemp);
                             personalingresado.getPila().mostrarPila();
                             
                             
                             
                             ListaEnlazada lista=gestion.getListaexpedientesfinalizados();
                             if(!lista.Estavacio()){
                                 Node<Expediente> temp=lista.getInicio();
                                 while(temp!=null){
                                     if(expedientetemp.getInteresado().equals(temp.getValor().getInteresado())){//si el interesado que hizo expediente es el mismo 
                                         Persona persona =temp.getValor().getInteresado();
                                         persona.getCola().Desencolar();
                                         break;
                                         
                                         
                                         
                                     }
                                     
                                     temp=temp.getNext();
                                 }
                                 
                                
                                 
                             }
                             
                            
                         
                        }
                    
                     
                     
                     }
                     
                     
                     
                     
                     
                     else{
                         System.out.println("has ingresado mal los datos: ");
                         break;
                         
                     }
                     break;
                         
                     
                    
                         
                      
            default:
                   System.out.println("HAZ SALIDO DEL PROGRAMA: ");
                   System.exit(0);
                
                 
        }
        }
                      
                  
       
                  
                  
                
                
                
    }
    

}
        
        
        
        
        
        
        
        
        
        
       
    

