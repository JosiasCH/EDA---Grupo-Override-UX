
package modeloLogica;
import java.util.ArrayList;
import java.util.List;

public class Gestion {
    private List<Usuario> listaUsuariosGUI;
    private ListaEnlazada listaEmpleados;//lista de empleados
    private ListaEnlazada listaPersonal;// lista de personal
    private ListaEnlazada listaexpedientesfinalizados; // lista de expedientesfinalizados
    private ListaEnlazada listaexpedientes;//lista de expedientes enviados
    private String ultimoUsuario;
    private String ultimaContraseña;
    private String ultimoTipoEmpleado;
    //GUI
    private ListaEnlazada listaUsuarios;  
    private ListaEnlazada listaContraseñas; 
    private ListaEnlazada listaTiposEmpleado;  
    public Gestion() {
        this.listaEmpleados = new ListaEnlazada();
        this.listaPersonal = new ListaEnlazada();
        this.listaexpedientesfinalizados = new ListaEnlazada();
        this.listaexpedientes=new ListaEnlazada();
        
        //GUI
        this.listaUsuarios = new ListaEnlazada();
        this.listaContraseñas = new ListaEnlazada();
        this.listaTiposEmpleado = new ListaEnlazada();
         this.listaUsuariosGUI = new ArrayList<>();
    }
   

    public void agregarUsuario(Usuario usuario) {
        listaUsuarios.Agregarelemento(usuario);
    }
    

    

    public ListaEnlazada getListaexpedientesfinalizados() {
        return listaexpedientesfinalizados;
    }

    public ListaEnlazada getListaexpedientes() {
        return listaexpedientes;
    }
    // GUI
    public String getUltimoUsuario() {
        return ultimoUsuario;
    }
    public void setUltimoUsuario(String ultimoUsuario) {
        this.ultimoUsuario = ultimoUsuario;
    }

    public String getUltimaContraseña() {
        return ultimaContraseña;
    }
    public void setUltimaContraseña(String ultimaContraseña) {
        this.ultimaContraseña = ultimaContraseña;
    }
    public String getUltimoTipoEmpleado() {
        return ultimoTipoEmpleado;
    }
    public void setUltimoTipoEmpleado(String ultimoTipoEmpleado) {
        this.ultimoTipoEmpleado = ultimoTipoEmpleado;
    }
        public void AgregarEmpleadoGUI(Empleado empleado) {
        listaEmpleados.Agregarelemento(empleado);
        ultimoUsuario = empleado.getUsuario();
        ultimaContraseña = empleado.getContraseña();
        ultimoTipoEmpleado = "Empleado";
    }

    public void AgregarPersonalGUI(Personal personal) {
        listaPersonal.Agregarelemento(personal);
        ultimoUsuario = personal.getUsuario();
        ultimaContraseña = personal.getContraseña();
        ultimoTipoEmpleado = "Personal";
    }
   
    
    //agregar empleado registrado
    public void AgregarEmpleado(Empleado empleado){
        listaEmpleados.Agregarelemento(empleado);
       
    }
    
    // agregar personal registrado
    public void AgregarPersonal(Personal personal){
        listaPersonal.Agregarelemento(personal);
       
    }
    // agregar expediente que aun no han sido finalizados
    public void AgregarExpediente(Expediente expediente){
        listaexpedientes.Agregarelemento(expediente);
    }
   
     public void agregarInformacionUsuario(String usuario, String contraseña, String tipoEmpleado) {
        listaUsuarios.Agregarelemento(usuario);
        listaContraseñas.Agregarelemento(contraseña);
        listaTiposEmpleado.Agregarelemento(tipoEmpleado);
    }       
        
        
        
        
    
     
    
    public ListaEnlazada getListaEmpleados() {
        return listaEmpleados;
    }

    

    public ListaEnlazada getListaPersonal() {
        return listaPersonal;
    }
    // GUI
    public boolean validarInicioSesion(String nombre, String contraseña) {
        if (!listaUsuarios.Estavacio()) {
            Node<Usuario> tempUsuario = listaUsuarios.getInicio();
            
            while (tempUsuario != null) {
                Usuario usuarioActual = tempUsuario.getValor();

                if (usuarioActual.getNombre().equals(nombre) && usuarioActual.getContraseña().equals(contraseña)) {
                    // Inicio de sesión exitoso
                    return true;
                }

                tempUsuario = tempUsuario.getNext();
            }
        }

        // No se encontró el usuario o la contraseña es incorrecta
        return false;
    }
    public ListaEnlazada<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }
   
public boolean ValidarEmpleadoGUI(String usuario, String contraseña) {
    if (!listaEmpleados.Estavacio()) {
        Node<Empleado> tempempleado = listaEmpleados.inicio;
        while (tempempleado != null) {
            if (tempempleado.getValor().getUsuario().equals(usuario) && tempempleado.getValor().getContraseña().equals(contraseña)) {
                return true;
            }
            tempempleado = tempempleado.getNext();
        }
    }
    System.out.println("Error: Validación de Empleado fallida");
    return false;
}
//GUI
public boolean ValidarPersonalGUI(String usuario, String contraseña) {
    if (!listaPersonal.Estavacio()) {
        Node<Personal> temppersonal = listaPersonal.inicio;
        while (temppersonal != null) {
            if (temppersonal.getValor().getUsuario().equals(usuario) && temppersonal.getValor().getContraseña().equals(contraseña)) {
                return true;
            }
            temppersonal = temppersonal.getNext();
        }
    }
    System.out.println("Error: Validación de Personal fallida");
    return false;
}
    
    //buscas en la lista de empleados a traves de un usuario y contraseña ingresados y retornar true si esta validado o false si no se encuentra en la lista  
     public boolean ValidarEmpleado(String usuario,String contraseña){
        
        if(!listaEmpleados.Estavacio()){
           Node<Empleado> tempempleado=listaEmpleados.inicio;
           
            while(tempempleado!=null  ){
               if(tempempleado.getValor().getUsuario().equals(usuario) && tempempleado.getValor().getContraseña().equals(contraseña)){
                   return true;
                   
               }
               tempempleado=tempempleado.getNext(); 
              
            }    
            
        }
        return false;
    
        
    
        
        
     
    }
     //buscas en la lista de personal a traves de un usuario y contraseña ingresados y retornar true si esta validado o false si no se encuentra en la lista
     public boolean ValidarPersonal(String usuario,String contraseña){
             if(!listaPersonal.Estavacio()){
                Node<Personal> temppersonal=listaPersonal.inicio;
           
               while(temppersonal!=null  ){
               if(temppersonal.getValor().getUsuario().equals(usuario) && temppersonal.getValor().getContraseña().equals(contraseña)){
                   return true;
                   
               }
               temppersonal=temppersonal.getNext(); 
              
            }    
            
        }
        return false;
       
      
     
    }
     // Para la interfaz GUI exclusivamente. Es necesario para obtener el tipo de usuario.
    public String obtenerTipoUsuario(String usuario, String contraseña) {
    if (ValidarEmpleado(usuario, contraseña)) {
        return "Empleado";
    } else if (ValidarPersonal(usuario, contraseña)) {
        return "Personal";
    } else {
        return null;
    }
}
    // buscas en la lista de empleados por usuario y contraseña si esta retorna el empleado que se encuentra en la lista
     public Empleado Retornarempleadovalidad(String usuario ,String contraseña){
         if(!listaEmpleados.Estavacio()){
           Node<Empleado> tempempleado=listaEmpleados.inicio;
           
            while(tempempleado!=null  ){
               if(tempempleado.getValor().getUsuario().equals(usuario) && tempempleado.getValor().getContraseña().equals(contraseña)){
                   return tempempleado.getValor();
                   
               }
               tempempleado=tempempleado.getNext(); 
              
            }    
            
        }
        return null;
     }
     // buscas en la lista de personal  un usuario y contraseña si este esta retorna el personal que se encuentra en la listadepersonal
     public Personal RetornarPersonalValidad(String usuario,String contraseña){
         if(!listaPersonal.Estavacio()){
                Node<Personal> temppersonal=listaPersonal.inicio;
           
               while(temppersonal!=null  ){
               if(temppersonal.getValor().getUsuario().equals(usuario) && temppersonal.getValor().getContraseña().equals(contraseña)){
                   return temppersonal.getValor();
                   
               }
               temppersonal=temppersonal.getNext(); 
              
            }    
            
        }
        return null;
         
     }
}
     
     
    
    
        
    
    
    
    

