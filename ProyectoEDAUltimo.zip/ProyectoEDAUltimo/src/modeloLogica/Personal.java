
package modeloLogica;


public class Personal extends Persona {
    private String dependencia;
   
    

    public Personal(String dependencia, String contraseña, String Usuario,  String Nombre, String Apellido, int Dni, String Correo, int codigo) {
        super(Nombre, Apellido, Dni, Correo, codigo,Usuario,contraseña);
        this.dependencia = dependencia;
        
       
       
    }

    @Override
    public String toString() {
        return "Personal{" + "dependencia=" + dependencia + '}';
    }

    public String getDependencia() {
        return dependencia;
        
    }

    public void setDependencia(String dependencia) {
        this.dependencia = dependencia;
    }
    
    
    //Busca en la lista de expedientes enviados por cualquier agente si es de su misma dependencia  lo encola en su cola y lo ordena de acuerdo a la prioridad
    public void RegistraIngresoExpediente(ListaEnlazada<Expediente> listaexpedientes){
        if(!listaexpedientes.Estavacio()){
            Node<Expediente> temp=listaexpedientes.inicio;
            
            while(temp!=null){
                Expediente expediente=temp.getValor();
               
                if(expediente.getDependencia().equals(dependencia)){
                    this.getCola().Encolar(expediente);
                    
                    
                }
               
              
                temp=temp.getNext();
            }
            
        }
        OrdenaRcolaPrioridad();
        
        
    }

   
    //ordernar la cola del personal para porder ser revisado y enviado  a otro personal o para poder ser revisado y finalizado
    public void OrdenaRcolaPrioridad(){
        Cola<Expediente> prionormal= new Cola();
        Cola<Expediente> priourgente=new Cola();
        
        while(!this.getCola().Estavacio()){
            Expediente temp=this.getCola().Desencolar();
            if(temp.getPrioridad()==2){
              priourgente.Encolar(temp);
            }else if(temp.getPrioridad()==1){
                prionormal.Encolar(temp);
            }
            
        }
        while(!priourgente.Estavacio()){
            this.getCola().Encolar(priourgente.Desencolar());
        }
        while(!prionormal.Estavacio()){
            this.getCola().Encolar(prionormal.Desencolar());
        }
    }

  
    
    
    
    
    
    
    
}
