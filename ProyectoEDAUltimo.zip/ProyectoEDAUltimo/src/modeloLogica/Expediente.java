
package modeloLogica;

import java.util.Objects;


public class Expediente {
    private int identificador;
    private int prioridad;
    private Persona interesado;
    private String asunto;
    private String dependencia;
    private Fecha fecha;
    private String estado;
    

    public Expediente(int identificador, int prioridad, Persona interesado, String asunto,String dependencia) {
        
        
        this.identificador = identificador;
        this.prioridad = prioridad;
        this.interesado = interesado;
        this.asunto = asunto;
        this.dependencia=dependencia;
        fecha=new Fecha();
        estado="Pendiente";
    }

    public int getIdentificador() {
        return identificador;
    }

    public void setDependencia(String dependencia) {
        this.dependencia = dependencia;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getEstado() {
        return estado;
    }

   
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Expediente other = (Expediente) obj;
        if (this.identificador != other.identificador) {
            return false;
        }
        if (this.prioridad != other.prioridad) {
            return false;
        }
        if (!Objects.equals(this.asunto, other.asunto)) {
            return false;
        }
        if (!Objects.equals(this.dependencia, other.dependencia)) {
            return false;
        }
        if (!Objects.equals(this.interesado, other.interesado)) {
            return false;
        }
        if (!Objects.equals(this.fecha, other.fecha)) {
            return false;
        }
        return true;
    }

    public String getDependencia() {
        return dependencia;
    }

    public Fecha getFecha() {
        return fecha;
    }

    public void setIdentificador(int identificador) {
        this.identificador = identificador;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public Persona getInteresado() {
        return interesado;
    }

    public void setInteresado(Persona interesado) {
        this.interesado = interesado;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    @Override
    public String toString() {
        return "Expediente{" + "identificador=" + identificador + ", prioridad=" + prioridad + ", interesado=" + interesado.toString() + ", asunto=" + asunto + ", dependencia=" + dependencia +fecha.toString()+ '}';
    }
    
    
    
    
    
    
}
