
package modeloLogica;
import java.time.LocalDate;
import java.time.LocalTime;

public class Fecha {
    LocalDate fecha;
    LocalTime horaactual;
    private int dia;
    private int mes;
    private int año;
    private int hora;
    
    
    
    public Fecha(){
        fecha=LocalDate.now();
        horaactual=LocalTime.now();
        dia=fecha.getDayOfMonth();
        mes=fecha.getMonthValue();
        año=fecha.getYear();
        hora=horaactual.getHour();
    }

    public int getHora() {
        return hora;
    }
    

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    @Override
    public String toString() {
        return "Fecha{" + "dia=" + dia + ", mes=" + mes + ", a\u00f1o=" + año + ", hora=" + hora + '}';
    }
    
}
