
package modeloLogica;
import java.util.Objects;
import java.util.Scanner;
import java.util.Random;

public class Empleado extends Persona {
     
     private String cargo;
    
    
     
     
     public Empleado(String Nombre, String Apellido, int Dni, String Correo, int codigo,String cargo,String usuario,String contraseña){
         super(Nombre,Apellido,Dni,Correo,codigo,usuario,contraseña);
         this.cargo=cargo;
         
        
         
         
         
     }

   

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empleado other = (Empleado) obj;
        if (!Objects.equals(this.cargo, other.cargo)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Empleado{" + "cargo=" + cargo +"Persona{" + "Nombre=" + this.getNombre() + ", Apellido=" +this.getApellido()+ ", Dni=" + this.getDni() + '}';
    }

    

   
   

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    
    //el empleado puede realizar un  expediente ingresando los atributos de, asunto, prioridad ,dependencia ,sus datos en automatico ,ademas del identificador
    public Expediente RealizarExpediente(){
        Scanner sc= new Scanner(System.in);
        System.out.println("Ingrese los  datos para realizar expediente: ");
        System.out.println(" ");
        System.out.println("Ingrese el asunto: ");
        String asunto=sc.next();
        System.out.println("Ingrese la prioridad del expediente : ");
        System.out.println("1.Normal");
        System.out.println("2.Urgente");
        
        int prioridad=sc.nextInt();
        System.out.println("Ingrese la dependencia: ");
        String Dependencia=sc.next();
        Random random= new Random();
        int identificador=random.nextInt(99999);
        
        Expediente expediente= new Expediente(identificador,prioridad,this,asunto,Dependencia);// se crea la dependencia
        
        
        this.getCola().Encolar(expediente);//se encola el expediente que llenaste en la cola de expedientes de este empleado
        return expediente;
            
        
       
        
        
        
        
        
    }
    
    //en seguir tramite la cola se ordena por prioridad y se muestra la cola para ver el estado de cada expediente
    public void SeguirTramite(){
        if(!this.getCola().Estavacio()){
            OrdenaRcolaPrioridad();
            
            this.getCola().Mostrar();
        }
        
    }

    
    //ordenas la cola del empleado para mostrarse primero sus expedientes que tienen mayor prioridad al comienzo y pones las colas de mayor prioridas
    public void OrdenaRcolaPrioridad(){
        
        Cola<Expediente> prionormal= new Cola();// 
        Cola<Expediente> priourgente=new Cola();
        
        while(!this.getCola().Estavacio()){
            Expediente temp=this.getCola().Desencolar();
            if(temp.getPrioridad()==2){
              priourgente.Encolar(temp);
            }else if(temp.getPrioridad()==1){
                prionormal.Encolar(temp);
            }
            
        }
        while(!priourgente.Estavacio()){
            this.getCola().Encolar(priourgente.Desencolar());
        }
        while(!prionormal.Estavacio()){
            this.getCola().Encolar(prionormal.Desencolar());
        }
    }
    
   
    
    
}
