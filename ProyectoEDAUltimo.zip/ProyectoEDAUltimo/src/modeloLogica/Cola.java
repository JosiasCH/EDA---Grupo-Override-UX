
package modeloLogica;

/**
 *
 * @author HP
 */
public class Cola<T> {
   
    protected Node<T> cabeza;
    protected Node<T> cola;
    //aaaaa
    
    
    
    public Cola(){
        cabeza=null;
        cola=null;
        
    }
  
    
    public boolean Estavacio(){
        if(cabeza==null){
            return true;
        }else{
            return false;
        }
    }
    
    public T Desencolar(){
        if(!Estavacio()){
            Node<T> temp=cabeza;
            cabeza=cabeza.getNext();
            return temp.getValor();
        }
        else{
            throw new RuntimeException("ERROR");
        }
    }
    public void Encolar(T valor){
        Node<T> nuevo=new Node(valor);
        if(Estavacio()){
            cola=nuevo;
            cabeza=nuevo;
        }else{
            cola.setNext(nuevo);
            cola=nuevo;
            
        }
        
    }
    public void Mostrar(){
        if(Estavacio()){
            System.out.println("error tu cola esta vacia");
            
        }else{
            Cola<T> aux=new Cola();
            T temp;
            while(!this.Estavacio()){
                temp=this.Desencolar();
                System.out.println(temp);
                aux.Encolar(temp);
            }
            while(!aux.Estavacio()){
                this.Encolar(aux.Desencolar());
            }
                
            
        }
        
    }
     public void eliminarRepetidos() {
        if (!Estavacio()) {
            Cola<T> aux = new Cola<>();
            while (!this.Estavacio()) {
                T temp = this.Desencolar();
                if (!aux.contiene(temp)) {
                    aux.Encolar(temp);
                }
            }
            while (!aux.Estavacio()) {
                this.Encolar(aux.Desencolar());
            }
        }
    }
    
    public boolean contiene(T valor) {
        Cola<T> aux = new Cola<>();
        boolean contieneValor = false;
        
        while (!this.Estavacio()) {
            T temp = this.Desencolar();
            if (temp.equals(valor)) {
                contieneValor = true;
            }
            aux.Encolar(temp);
        }
        
        while (!aux.Estavacio()) {
            this.Encolar(aux.Desencolar());
        }
        
        return contieneValor;
    }

}
    

