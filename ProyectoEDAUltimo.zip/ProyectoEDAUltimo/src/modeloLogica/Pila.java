/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloLogica;

/**
 *
 * @author Usuario
 */

    public class Pila<T> {
    // Atributos
    private Node<T> top;
    
    // Constructor para crear una pila
    public Pila(){ // objeto pila totalmente vacia
        top = null;
    }
    // Otro metodos
    // Verifica si una pila esta vacia
    public boolean isEmpty(){
        return top == null;
    }
    // push() - Apilar: Añade un elemento en la cima de la pila
    public void push(T elemento){
        Node<T> nuevoNodo = new Node(elemento);
        if (isEmpty()){
            top = nuevoNodo;
        }else{ // la pila no esta vacia
            nuevoNodo.setNext(top);
            top = nuevoNodo;
        }
    }
    // pop() - desapilar: Sacar un elemento de la pila
    public T pop(){
        T elemento = null;
        if (!isEmpty()){
            // eliminar el nodo de la cima
            elemento = top.getValor();
            top = top.getNext();
        }
        return elemento;
    }
     public void mostrarPila() {
        if (isEmpty()) {
            System.out.println("No has hecho ningun expediente.");
            return;
        }

        System.out.println("ESTAS SON TUS EXPEDIENTES REALIZADOS:");

        Pila<T> pilaAuxiliar = new Pila<>();
        while (!isEmpty()) {
            T elemento = pop();
            System.out.println(elemento);
            pilaAuxiliar.push(elemento);
        }

        // Restaurar la pila original
        while (!pilaAuxiliar.isEmpty()) {
            push(pilaAuxiliar.pop());
        }
    }
    
}

