/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloLogica;

/**
 *
 * @author Usuario
 */
public class ListaEnlazada<T> {
    protected Node<T> inicio;
    protected Node<T> ultimo;

    public ListaEnlazada() {
        this.inicio = null;
        this.ultimo = null;
    }
    
    public  boolean Estavacio(){
        if(inicio==null){
            return true;
        }else{
            return false;
        }
        
    }
    public void  Agregarelemento(T valor){
        Node<T> nuevo= new Node<T>(valor);
        if(Estavacio()){
           inicio=nuevo;
           ultimo=nuevo;
        }else{
            ultimo.setNext(nuevo);
            ultimo=nuevo;
           
    
            
        }
        
    }
    

    public Node<T> getInicio() {
        return inicio;
    }

    public Node<T> getUltimo() {
        return ultimo;
    }
    public void ImprimirLista(){
        if(!Estavacio()){
            Node<T> temp=inicio;
            while(temp!=null){
                System.out.print(temp.getValor()+"->");
                temp=temp.getNext();
                
            }
            
            
        }
    }
    public void EliminarElementodeLista(T elemento){
        if(!Estavacio()){
            Node<T> temp=inicio;
            Node<T> anterior=null;
            if (temp != null && temp.getValor().equals(elemento)) {
            inicio = temp.getNext();
            return;
            }

            
            while (temp != null && !temp.getValor().equals(elemento)) {
            anterior = temp;
            temp = temp.getNext();
            }

      
            if (temp != null) {
            anterior.setNext(temp.getNext());
             }
        }
    }
   
    
    
    

}  
    
    
    
    
    
    

