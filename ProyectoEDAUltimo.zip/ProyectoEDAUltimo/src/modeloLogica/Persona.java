
package modeloLogica;

import java.util.Objects;


public class Persona {
    private String Nombre;
    private String Apellido;
    private int Dni;
    private  String Correo;
    private String usuario;
    private String contraseña;
     private Cola<Expediente> cola;
     private Pila<Expediente> pila;
   
    private int codigo;

    public Persona(String Nombre, String Apellido, int Dni, String Correo, int codigo,String usuario,String contraseña) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Dni = Dni;
        this.Correo = Correo;
        this.codigo = codigo;
        this.usuario=usuario;
        this.contraseña=contraseña;
        cola=new Cola();
        pila=new Pila();
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Persona other = (Persona) obj;
        if (this.Dni != other.Dni) {
            return false;
        }
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.Nombre, other.Nombre)) {
            return false;
        }
        if (!Objects.equals(this.Apellido, other.Apellido)) {
            return false;
        }
        if (!Objects.equals(this.Correo, other.Correo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.contraseña, other.contraseña)) {
            return false;
        }
        return true;
    }

    public Cola<Expediente> getCola() {
        return cola;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getDni() {
        return Dni;
    }

    public void setDni(int Dni) {
        this.Dni = Dni;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

   

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    @Override
    public String toString() {
        return "Persona{" + "Nombre=" + Nombre + ", Apellido=" + Apellido + ", Dni=" + Dni + ", Correo=" + Correo + ", usuario=" + usuario + ", contrase\u00f1a=" + contraseña + ", codigo=" + codigo + '}';
    }

    public Pila<Expediente> getPila() {
        return pila;
    }

   
    
    
    
    
    
    
}
